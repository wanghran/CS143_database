505029637, 605023965
My job is to setup the database from the last project and ensure the request of webpage will be dealt correctly.